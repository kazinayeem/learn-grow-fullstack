import { z } from "zod";

export const createUserSchema = z.object({
  body: z.object({
    name: z.string().min(2, "Name must be at least 2 characters"),
    phone: z.string().min(10, "Phone must be at least 10 characters"),
    email: z.string().email("Invalid email address").optional().or(z.literal("")),
    password: z.string().min(6, "Password must be at least 6 characters"),
    role: z.enum(["student", "instructor", "guardian", "admin", "manager"]).refine(
      (val) => ["student", "instructor", "guardian", "admin", "manager"].includes(val),
      { message: "Role must be student, instructor, guardian, admin, or manager" }
    ),
  }),
});

export const sendOtpSchema = z.object({
  body: z.object({
    email: z.string().email("Invalid email address").optional().or(z.literal("")),
    phone: z.string().min(10, "Phone must be at least 10 characters").optional().or(z.literal("")),
  }).refine((data) => data.email || data.phone, {
    message: "Either email or phone is required",
  }),
});

export const verifyOtpSchema = z.object({
  body: z.object({
    email: z.string().email().optional(),
    phone: z.string().optional(),
    otp: z.string().length(6, "OTP must be 6 digits"),
  }),
});

export const registerSchema = z.object({
  body: z.object({
    name: z.string().min(2, "Name must be at least 2 characters"),
    email: z.string().email("Invalid email address").optional(),
    phone: z.string().min(10, "Phone must be at least 10 characters").optional(),
    password: z.string().min(6, "Password must be at least 6 characters"),
    role: z.enum(["student", "instructor", "guardian", "admin", "manager"]),
  }).refine((data) => data.email || data.phone, {
    message: "Either email or phone is required",
  }),
});

export const loginSchema = z.object({
  body: z.object({
    email: z.string().email().optional(),
    phone: z.string().optional(),
    password: z.string().min(6, "Password must be at least 6 characters"),
  }).refine((data) => data.email || data.phone, {
    message: "Either email or phone is required",
  }),
});

export const changePasswordSchema = z.object({
  body: z.object({
    oldPassword: z.string(),
    newPassword: z.string().min(6, "Password must be at least 6 characters"),
  }),
});

export const forgotPasswordSchema = z.object({
  body: z.object({
    email: z.string().email("Invalid email address"),
  }),
});

export const verifyForgotPasswordOtpSchema = z.object({
  body: z.object({
    email: z.string().email("Invalid email address"),
    otp: z.string().length(6, "OTP must be 6 digits"),
  }),
});

export const resetPasswordSchema = z.object({
  body: z.object({
    email: z.string().email("Invalid email address"),
    otp: z.string().length(6, "OTP must be 6 digits"),
    newPassword: z.string().min(8, "Password must be at least 8 characters"),
  }),
});

export const refreshTokenSchema = z.object({
  body: z.object({
    refreshToken: z.string(),
  }),
});

export const sendPasswordChangeOtpSchema = z.object({
  body: z.object({
    email: z.string().email("Invalid email address").optional(),
    phone: z.string().min(10, "Phone must be at least 10 characters").optional(),
  }).refine((data) => data.email || data.phone, {
    message: "Either email or phone is required",
  }),
});

export const verifyPasswordChangeOtpSchema = z.object({
  body: z.object({
    email: z.string().email().optional(),
    phone: z.string().optional(),
    otp: z.string().length(6, "OTP must be 6 digits"),
    newPassword: z.string().min(6, "Password must be at least 6 characters"),
  }).refine((data) => data.email || data.phone, {
    message: "Either email or phone is required",
  }),
});

export const updatePhoneNumberSchema = z.object({
  body: z.object({
    newPhone: z.string().min(10, "Phone must be at least 10 characters"),
  }),
});

export const updateProfileSchema = z.object({
  body: z.object({
    name: z.string().min(2, "Name must be at least 2 characters").optional(),
    bio: z.string().optional(),
    phone: z.string().optional(),
    expertise: z.string().optional(),
    qualification: z.string().optional(),
    institution: z.string().optional(),
    yearsOfExperience: z
      .preprocess((val) => {
        if (typeof val === "string" && val.trim() !== "") return Number(val);
        return val;
      }, z.number().optional()),
  }),
});

export const updateProfilePhotoSchema = z.object({
  body: z.object({
    profileImage: z.string().min(1, "Profile image is required"),
  }),
});
