export { default as settingsRoutes } from "./routes/settings.routes.js";
