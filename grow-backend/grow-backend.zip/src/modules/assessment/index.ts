export { default as assessmentRoutes } from "./routes/assessment.route.js";
