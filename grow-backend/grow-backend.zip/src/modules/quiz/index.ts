export { default as quizRoutes } from "./routes/quiz.routes.js";
