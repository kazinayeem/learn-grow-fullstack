export { default as courseRoutes } from "./routes/course.route.js";
export { Course } from "./model/course.model.js";
export { Module } from "./model/module.model.js";
export { Lesson } from "./model/lesson.model.js";