export { default as siteContentRoutes } from "./routes/siteContent.routes.js";
