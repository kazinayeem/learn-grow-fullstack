export { default as statusRoutes } from "./routes/status.routes.js";
